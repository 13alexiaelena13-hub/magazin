import React, { useState, useEffect } from "react";

/*
Simple functional frontend-only React app for a furniture-made-to-order shop.
Stores orders in localStorage. Ready to build & deploy as a static site (Vercel, Netlify, GitHub Pages).
*/

const SAMPLE_PRODUCTS = [
  {
    id: 1,
    name: "Masă din stejar la comandă",
    description:
      "Masă solidă din stejar, finisaje la alegere. Se poate personaliza dimensiunea și tipul picioarelor.",
    basePrice: 1200,
    image:
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=1",
    dimensions: ["120x80 cm", "140x90 cm", "160x90 cm"],
    materials: ["Stejar", "Fag", "Nuc"],
    finishes: ["Natural", "Lacuit mat", "Lacuit lucios"],
  },
  {
    id: 2,
    name: "Canapea modulară",
    description:
      "Canapea modulară tapitată, modularitate 2-4 locuri, texturi și culori variabile.",
    basePrice: 2300,
    image:
      "https://images.unsplash.com/photo-1585559602142-1b8de25b1b2d?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=2",
    dimensions: ["2 locuri", "3 locuri", "Colțar"],
    materials: ["Bumbac", "Catifea", "Piele ecologică"],
    finishes: ["Clasic", "Modern"],
  },
  {
    id: 3,
    name: "Corp de mobilier pentru living",
    description:
      "Compoziție personalizată pentru televizoare, rafturi și iluminare ambientala.",
    basePrice: 950,
    image:
      "https://images.unsplash.com/photo-1600585154358-8a0a7b2a0c1f?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=3",
    dimensions: ["180 cm", "220 cm", "260 cm"],
    materials: ["MDF vopsit", "Lemn masiv"],
    finishes: ["Alb mat", "Stejar fumuriu"],
  },
];

export default function App() {
  const [products] = useState(SAMPLE_PRODUCTS);
  const [selected, setSelected] = useState(null);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [orders, setOrders] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("mm_orders")) || [];
    } catch (e) {
      return [];
    }
  });
  const [adminMode, setAdminMode] = useState(false);

  useEffect(() => {
    localStorage.setItem("mm_orders", JSON.stringify(orders));
  }, [orders]);

  function openConfigurator(product) {
    setSelected({
      ...product,
      choice: {
        dimension: product.dimensions[0],
        material: product.materials[0],
        finish: product.finishes[0],
        quantity: 1,
      },
    });
    setShowOrderModal(true);
  }

  function placeOrder(client) {
    if (!client || !client.name || !client.phone) {
      alert("Completează numele și telefonul pentru a plasa comanda.");
      return;
    }
    const timestamp = new Date().toISOString();
    const id = "ORD-" + Math.random().toString(36).slice(2, 9).toUpperCase();
    const newOrder = {
      id,
      createdAt: timestamp,
      productId: selected?.id || null,
      productName: selected?.name || "Comandă personalizată",
      configuration: selected?.choice || {},
      client,
      status: "Nou",
    };
    setOrders((s) => [newOrder, ...s]);
    setShowOrderModal(false);
    setSelected(null);
    alert("Comanda a fost înregistrată — ID: " + id + "\nVeți fi contactat(ă) pentru confirmare.");
  }

  function exportCSV() {
    if (!orders.length) {
      alert("Nu există comenzi de exportat.");
      return;
    }
    const headers = [
      "ID",
      "Data",
      "Produs",
      "Dimensiune",
      "Material",
      "Finisaj",
      "Cantitate",
      "Nume client",
      "Telefon",
      "Email",
      "Adresă",
      "Status",
    ];
    const rows = orders.map((o) => [
      o.id,
      o.createdAt,
      o.productName,
      o.configuration?.dimension || "",
      o.configuration?.material || "",
      o.configuration?.finish || "",
      o.configuration?.quantity || "",
      o.client?.name || "",
      o.client?.phone || "",
      o.client?.email || "",
      o.client?.address || "",
      o.status || "",
    ]);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `magazin_mobilier_comenzi_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function AdminPanel() {
    const [pass, setPass] = useState("");
    const check = () => setAdminMode(pass === "mobilier123");
    return (
      <div className="panel">
        <h3>Panou administrare</h3>
        {!adminMode ? (
          <div>
            <p>Introduceți parola pentru a vedea comenzile (demo: mobilier123)</p>
            <input placeholder="Parola" value={pass} onChange={(e) => setPass(e.target.value)} />
            <button onClick={check}>Autentificare</button>
          </div>
        ) : (
          <div>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <strong>{orders.length} comenzi</strong>
              <div>
                <button onClick={() => { localStorage.removeItem('mm_orders'); setOrders([]); }}>Șterge tot</button>
                <button onClick={exportCSV}>Export CSV</button>
              </div>
            </div>
            <div className="orders-list">
              {orders.map((o) => (
                <div key={o.id} className="order">
                  <div>
                    <div className="bold">{o.id} — {o.productName}</div>
                    <div className="muted">{new Date(o.createdAt).toLocaleString()}</div>
                    <div className="muted">{o.client?.name} • {o.client?.phone} • {o.client?.email}</div>
                    <div>{o.configuration?.quantity} × {o.configuration?.material} — {o.configuration?.dimension}</div>
                  </div>
                  <div style={{textAlign:'right'}}>
                    <div>{o.status}</div>
                    <button onClick={() => updateStatus(o.id)}>Schimbă status</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );

    function updateStatus(id) {
      const next = orders.map((o) => (o.id === id ? { ...o, status: nextStatus(o.status) } : o));
      setOrders(next);
    }
    function nextStatus(s) {
      if (s === "Nou") return "Confirmată";
      if (s === "Confirmată") return "Producție";
      if (s === "Producție") return "Finalizată";
      return "Finalizată";
    }
  }

  function ProductCard({ p }) {
    return (
      <div className="card">
        <img src={p.image} alt={p.name} />
        <div className="card-body">
          <div className="title">{p.name}</div>
          <div className="desc">{p.description}</div>
          <div className="row">
            <div className="price">{p.basePrice} RON</div>
            <div className="actions">
              <button onClick={() => openConfigurator(p)}>Configurează</button>
              <button onClick={() => { setSelected(p); setShowOrderModal(true); }}>Comandă</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  function OrderModal() {
    const [client, setClient] = useState({ name: "", phone: "", email: "", address: "" });
    useEffect(() => {
      if (!selected) return;
      setClient({ name: "", phone: "", email: "", address: "" });
    }, [selected]);

    if (!selected) return null;
    return (
      <div className="modal-backdrop">
        <div className="modal">
          <button className="close" onClick={() => { setShowOrderModal(false); setSelected(null); }}>✕</button>
          <div className="modal-grid">
            <div>
              <img src={selected.image} alt={selected.name} className="img-large" />
              <h3>{selected.name}</h3>
              <p className="muted">{selected.description}</p>
              <div className="form-group">
                <label>Dimensiune</label>
                <select value={selected.choice.dimension} onChange={(e) => setSelected(s => ({ ...s, choice: { ...s.choice, dimension: e.target.value } }))}>
                  {selected.dimensions.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
                <label>Material</label>
                <select value={selected.choice.material} onChange={(e) => setSelected(s => ({ ...s, choice: { ...s.choice, material: e.target.value } }))}>
                  {selected.materials.map((m) => <option key={m} value={m}>{m}</option>)}
                </select>
                <label>Finisaj</label>
                <select value={selected.choice.finish} onChange={(e) => setSelected(s => ({ ...s, choice: { ...s.choice, finish: e.target.value } }))}>
                  {selected.finishes.map((f) => <option key={f} value={f}>{f}</option>)}
                </select>
                <label>Cantitate</label>
                <input type="number" min={1} value={selected.choice.quantity} onChange={(e) => setSelected(s => ({ ...s, choice: { ...s.choice, quantity: Number(e.target.value) } }))} />
              </div>
            </div>
            <div>
              <h4>Date client</h4>
              <input placeholder="Nume complet" value={client.name} onChange={(e) => setClient({ ...client, name: e.target.value })} />
              <input placeholder="Telefon" value={client.phone} onChange={(e) => setClient({ ...client, phone: e.target.value })} />
              <input placeholder="Email" value={client.email} onChange={(e) => setClient({ ...client, email: e.target.value })} />
              <input placeholder="Adresă de livrare" value={client.address} onChange={(e) => setClient({ ...client, address: e.target.value })} />
              <div style={{marginTop:12}}>
                <div className="muted">Sumar preț (estimativ)</div>
                <div className="big">{estimatePrice(selected)} RON</div>
                <div style={{marginTop:8}}>
                  <button onClick={() => placeOrder(client)}>Plasează comanda</button>
                  <button onClick={() => { setShowOrderModal(false); setSelected(null); }}>Anulează</button>
                </div>
                <div className="muted small">După trimitere veți fi contactat(ă) pentru confirmare, măsurători și avans.</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );

    function estimatePrice(s) {
      if (!s) return "--";
      let price = s.basePrice || 0;
      if (s.choice.material.toLowerCase().includes("nuc")) price += 400;
      if (s.choice.finish.toLowerCase().includes("lucios")) price += 120;
      price *= s.choice.quantity || 1;
      return price;
    }
  }

  return (
    <div className="page">
      <header className="header">
        <div className="brand">MagazinMobilier</div>
        <nav>
          <a href="#showroom">Showroom</a>
          <a href="#despre">Despre</a>
          <a href="#contact">Contact</a>
          <button onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}>Comandă</button>
        </nav>
      </header>

      <main className="container">
        <section className="hero">
          <div>
            <h1>Mobilier la comandă — design românesc, execuție atentă</h1>
            <p>Realizăm piese unice sau serie mică, din materiale alese, cu măsurători și livrare la domiciliu.</p>
            <div className="cta">
              <button onClick={() => document.getElementById('showroom')?.scrollIntoView({ behavior: 'smooth' })}>Vezi showroom</button>
              <button onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>Contact</button>
            </div>
          </div>
          <div>
            <img src="https://images.unsplash.com/photo-1598300100238-2d9d4a3f6ae2?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=4" alt="showroom" />
          </div>
        </section>

        <section id="showroom">
          <div className="section-header">
            <h2>Showroom — piese recomandate</h2>
            <div className="muted">Apasă Configurează pentru a personaliza</div>
          </div>
          <div className="grid">
            {products.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        </section>

        <section id="despre" className="card-light">
          <h3>Despre noi</h3>
          <p className="muted">Suntem o echipă mică de meșteri și designeri care pun accent pe materiale durabile, finisaje de calitate și comunicare transparentă.</p>
          <div className="features">
            <div className="feature">Măsurători la domiciliu</div>
            <div className="feature">Proiectare 3D & prototip</div>
            <div className="feature">Livrare & montaj</div>
          </div>
        </section>

        <section id="contact" className="grid-2">
          <div>
            <h4>Contact</h4>
            <p className="muted">Telefon: +40 700 000 000<br/>Email: contact@magazinmobilier.example</p>
            <p className="muted">Program: L-V 9:00 - 18:00</p>
            <div className="quick-contact">
              <h5>Comandă rapidă</h5>
              <QuickContact onSubmit={(data) => { const id = 'QC-' + Math.random().toString(36).slice(2,8).toUpperCase(); setOrders(s => [{ id, createdAt: new Date().toISOString(), productId: null, productName: 'Cerere ofertă', configuration: {}, client: data, status: 'Cere ofertă' }, ...s]); alert('Cererea a fost trimisă — ID: ' + id); }} />
            </div>
          </div>
          <div>
            <AdminPanel />
          </div>
        </section>

        <footer className="footer">© {new Date().getFullYear()} MagazinMobilier • Toate drepturile rezervate</footer>
      </main>

      {showOrderModal && selected && <OrderModal />}
    </div>
  );
}

function QuickContact({ onSubmit }) {
  const [data, setData] = useState({ name: "", phone: "", email: "", notes: "" });
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit({ name: data.name || 'Anonim', phone: data.phone, email: data.email, address: data.notes }); setData({ name: '', phone: '', email: '', notes: '' }); }} className="quick-form">
      <input placeholder="Nume" value={data.name} onChange={(e) => setData({ ...data, name: e.target.value })} />
      <input placeholder="Telefon" value={data.phone} onChange={(e) => setData({ ...data, phone: e.target.value })} />
      <input placeholder="Email" value={data.email} onChange={(e) => setData({ ...data, email: e.target.value })} />
      <textarea placeholder="Scurtă descriere proiect / adresă" value={data.notes} onChange={(e) => setData({ ...data, notes: e.target.value })} />
      <div style={{display:'flex',gap:8}}>
        <button type="submit">Trimite</button>
        <button type="button" onClick={() => setData({ name: '', phone: '', email: '', notes: '' })}>Reset</button>
      </div>
    </form>
  );
}
