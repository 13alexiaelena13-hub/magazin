# Magazin Mobilier — Site (frontend)

Acesta este un proiect frontend React (Vite) demo pentru un magazin de mobilier la comandă.
- Funcționalitate: prezentare produse, configurator, plasare comenzi (salvate în `localStorage`), panou admin local (parolă demo `mobilier123`), export CSV.
- Deploy: site static — se poate publica imediat pe **Vercel / Netlify / GitHub Pages**.

## Pași rapizi pentru live (Vercel)
1. Descarcă acest pachet (.zip) și actualizează conținutul (imagini, texte) dacă vrei.
2. Încarcă codul într-un repo GitHub.
3. Conectează repo-ul la Vercel (https://vercel.com) și apasă **Deploy**. Site-ul va fi public în câteva secunde.
4. După deploy, site-ul este vizibil public. Notă: comenzile sunt stocate local în browser (localStorage). Pentru stocare centrală, urmează pașii din secțiunea *Backend / Stocare*.

## Backend / Stocare permanentă (opțiuni)
- **Supabase**: creare proiect Supabase și integrare (recomandat, gratuit tier).
- **API Express + PostgreSQL**: găzduire pe Render/Heroku/Render + DB.
Dacă vrei, îți pot genera și cod backend + instrucțiuni de deploy.

## Cum rulezi local
1. `npm install`
2. `npm run dev`
3. Deschide `http://localhost:5173`

---
